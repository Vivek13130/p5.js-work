// another moving graph for perlin noise 
let start = 0; // the start point in our perlin graph 
let xoff ;
let xdiff = 0.001;


function setup() {
  createCanvas(400, 400);
  frameRate(60);
}

// what we can do is add some sin waves or cosine waves with noise to get much better results .

function draw() {
  background(220);
  // noFill()
  // we will use begin shape for this : 
  stroke(0);
  strokeWeight(3);
  
  fill(255,255,0); // you can remove this to remove the yellow color 
  // noFill();
  
  beginShape();
  
  xoff = start;
  
  for(let i = 0; i<width ; i++){
    
    // random values : 
    // point(i,random(0,height))
    
    // vertex(i, random(0,height));
    
    // now graphing perlin noise : 
    let y = noise(xoff)*height;
    
    vertex(i,y);
    
    xoff += xdiff;
    
  }
  
  start += 0.01;
  endShape();
  // the shape will be completed if we define the point as vertices .
  
  
}