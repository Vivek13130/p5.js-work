// now we have created behaviour for one rectangle , so now we will make it for future use

// in this file we will define the class only and rest all happens in the other file .

class Block {
  constructor(x, y) {
    // x and y are location of the center
    this.x = x;
    this.y = y;
    // we have set up the center of rectangle

    this.angle = 0; // this will store the rotation angle of every object

    this.c = 75;
    // this.stroke_color_r = random(0,256);
    // this.stroke_color_g = random(0,256);
    // this.stroke_color_b = random(0,256);
  }

  display() {
    // this function is responsible for
    // this is not an inbuilt method , but it is usually used to draw the objects .just a convention
    // this function will be used to display the rectangle :
    // here we have translated the origin to center of a particular rectangle .

    // we are using push and pop so that properties done for one rectangle object does not mess around with the other object .
    push();

    // stroke(this.stroke_color_r,this.stroke_color_g,this.stroke_color_b);
    stroke(this.c);
    translate(this.x, this.y);
    rotate(this.angle);
    rect(0, 0, size - offset, size - offset);

    pop();
  }

  move() {
    // this function is responsible for rotation of the square

    if (this.c > 75) {
      this.c -= disappear_speed;
    }

    if (pmouseX != mouseX || pmouseY != mouseY || this.angle > 0) {
      if (this.angle > 0 && this.c <= 75) {
        this.c = 256;
      }

      let distance = dist(mouseX, mouseY, this.x, this.y);

      // if(distance < sensing_dist){this.c = 256;}

      if (distance < sensing_dist || (this.angle > 0 && this.angle < 90)) {
        this.angle += rotation_speed;

        if (this.angle >= 90) {
          this.angle = 0;
        }
      }
    }
  }
}
