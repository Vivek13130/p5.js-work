let xrp = 0;
let yrp = 0;

let xn = 0;
let x1 = 0;
let ynp = 0;


function setup() {
  createCanvas(4000, 400);
  background(220);
  
}

function graph_random(mini, maxi){
  let y = random(mini, maxi);
  
  line(xrp, yrp , xrp+2, y);
  xrp += 2; 
  yrp = y;
}

function graph_perlin(xoff){
  
  let val = noise(xn);
  let yn = map(val, 0, 1, 0,100)
  
  xn += xoff;
  
  line(x1,ynp, x1+2, yn);
  ynp = yn;
  x1 = x1+2;
}

function draw() {
  // you can specify the range in function 
  translate(0,height/5);
  
  graph_random(0,100);
  
  translate(0,0);
  translate(0,2*height/5);
  
  
  // here you can give the offset value;
  graph_perlin(0.02);
}