class star {
  constructor(x, y, m = 30) {
    this.pos = createVector(x, y);
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.force = createVector(0, 0);
    this.mass = m;
    this.size = 15;
  }

  move() {
    this.acc = this.force.mult(1 / this.mass);
    this.acc.setMag(0.001);
    this.vel.add(this.acc);
    this.vel.limit(0.7);
    this.pos.add(this.vel);
  }

  display() {
    ellipse(this.pos.x, this.pos.y, this.size, this.size);
  }
}
