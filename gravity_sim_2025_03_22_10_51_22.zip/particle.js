
class particle {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = createVector(random(-5, 5), random(-5, 5));
    this.acc = createVector(0, 0);
    this.force = createVector(0, 0);
    this.mass = 1;

    // array for storing previous positions , to show trails
    this.trail = [];
    this.size = 5;
    
    this.sw = 3; // this is initial stroke weight
  }

  move() {
    this.acc = this.force.mult(1 / this.mass);
    this.acc.limit(accn_limit_p);

    this.vel.add(this.acc);

    // adding a limit to velocity :
    this.vel.limit(vel_limit_p);

    this.pos.add(this.vel);
  }

  display() {
    stroke(255,242,0);
    strokeWeight(7);
    point(this.pos.x, this.pos.y);
  }

  update_trail(l1) {
    this.trail.push(this.pos.copy());
    if (this.trail.length > l1) {
      this.trail.shift(); 
    }
  }

  display_trail() {
    push();
    stroke(255);
    for (let i = 1; i < this.trail.length; i++) {
      strokeWeight(trail_width);
      line(this.trail[i-1].x, this.trail[i-1].y , this.trail[i].x, this.trail[i].y);
    }
    pop();
}



}
