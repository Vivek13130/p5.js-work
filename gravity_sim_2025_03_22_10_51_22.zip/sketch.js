// ------------------------------------------------------
let G = 5; // the gravitational constant between stars and particles
let G1 = 0.1; // this is between stars and stars

let trail = true; // show trail
let interaction = true; // shows the forces interaction between particles and stars

let veldir = true; // enable direction of vel on particles
let accdir = true; // enable direction of accn on particles

let enabletrail = true;
let trail_length = 10; // trail length of particles

let accn_limit_p = 1; // max accn of particles
let vel_limit_p = 10; // max vel of particles
let trail_width = 1; // this is the trail width;

let random_particles = true; // set initially some random particles 
let amount = 20;

let avgdisplay = true; // average vel and acceration of particles.

// ------------------------------------------------------

let particles = [];
let stars = [];

let addparticles = false;

function setup() {
  createCanvas(windowWidth, windowHeight);
  // background(45);
  frameRate(30);

  if (random_particles) {
    for (let i = 0; i < amount; i++) {
      particles.push(
        new particle(random(0, windowWidth), random(0, windowHeight))
      );
    }
  }
}

function draw() {
  background(24);

  if (addparticles) {
    particles.push(new particle(mouseX, mouseY));
  }

  let avgvel = createVector(0, 0);
  let avgacc = createVector(0, 0);

  // display  particles
  for (let i = 0; i < particles.length; i++) {
    particles[i].move();
    particles[i].display();

    avgvel.add(particles[i].vel);
    avgacc.add(particles[i].acc);

    if (enabletrail) {
      particles[i].update_trail(trail_length);
      particles[i].display_trail();
    }

    // deleting the particles , if out of bound
    if (
      particles[i].pos.x > windowWidth * 2 ||
      particles[i].pos.x < -windowWidth * 2
    ) {
      particles.splice(i, 1);
      console.log("deleted due to x");
    } else if (
      particles[i].pos.y > windowHeight * 2 ||
      particles[i].pos.y < -windowHeight * 2
    ) {
      particles.splice(i, 1);
      console.log("deleted due to y");
    }

    if (veldir) {
      push();
      stroke(20, 91, 245);
      strokeWeight(2);

      let linevec = particles[i].vel.copy();
      linevec.setMag(10);

      line(
        particles[i].pos.x,
        particles[i].pos.y,
        particles[i].pos.x + linevec.x,
        particles[i].pos.y + linevec.y
      );
      pop();
    }

    if (accdir) {
      push();
      stroke(242, 10, 48);
      strokeWeight(2);

      let linevec = particles[i].acc.copy();
      linevec.setMag(15);

      line(
        particles[i].pos.x,
        particles[i].pos.y,
        particles[i].pos.x + linevec.x,
        particles[i].pos.y + linevec.y
      );
      pop();
    }

    avgvel.setMag(avgvel.mag / particles.length);
    avgacc.setMag(avgacc.mag / particles.length);

    display_avg_vel_acc(avgvel, avgacc);
  }

  // display stars :
  for (let i = 0; i < stars.length; i++) {
    stars[i].move();
    stars[i].display();
  }

  //   ----------------------------------------------------
  // processing

  // forces -- on particles by  star :
  for (let j = 0; j < particles.length; j++) {
    let totalForce = createVector(0, 0);

    for (let i = 0; i < stars.length; i++) {
      let distance = p5.Vector.sub(stars[i].pos, particles[j].pos);
      let distanceMag = distance.mag(); // Use magSq() for performance
      let forceMagnitude =
        (G * stars[i].mass * particles[j].mass) / distanceMag;

      let force = distance.copy().setMag(forceMagnitude);

      totalForce.add(force);

      // interaction of particle with stars :
      if (interaction && forceMagnitude > 1) {
        push();
        let weight = map(forceMagnitude, 1, 10, 0.1, 2);
        if (weight > 2) {
          weight = 2;
        }
        strokeWeight(weight);
        stroke(48, 252, 3);

        line(
          stars[i].pos.x,
          stars[i].pos.y,
          particles[j].pos.x,
          particles[j].pos.y
        );
        pop();
      }
    }
    particles[j].force = totalForce;
  }

  //  gravity-force between stars :
  for (let i = 0; i < stars.length; i++) {
    for (let j = 0; j < stars.length; j++) {
      if (j == i) {
        continue;
      }

      let distance = p5.Vector.sub(stars[j].pos, stars[i].pos);
      let distanceMag = distance.mag(); // Calculate magnitude of distance vector

      let force =
        (G1 * stars[i].mass * stars[j].mass) / (distanceMag * distanceMag);

      stars[i].force.add(distance.copy().setMag(force));

      // making the stars merge :
      if (distanceMag < 10 && stars.length > 1) {
        stars[j].mass += stars[i].mass;
        stars[j].size += stars[i].size / 3;
        stars.splice(i, 1);
      }
    }
  }

  // adding some stats on the screen :
  textSize(16);
  textAlign(LEFT);
  // text("stars - " + stars.length, 40, 10);
  // text("particles - " + particles.length, 0, 40);
}

// extra functions : ------------------

function display_avg_vel_acc(avgvel, avgacc) {
  avgvel.setMag(20);
  avgacc.setMag(20);

  push();
  fill(26, 15, 14);
  rect(0, 0, 50, 50);
  ellipse(25, 25, 15, 15);

  translate(25, 25);

  stroke(0, 0, 255);
  strokeWeight(2);
  line(0, 0, avgvel.x, avgvel.y);

  stroke(255, 0, 0);
  strokeWeight(1);
  line(0, 0, avgacc.x, avgacc.y);

  pop();
}
function mousePressed() {
  if (mouseButton == LEFT) add_dark_star();
}

function keyPressed() {
  if (key === "a" || key === "A") {
    addparticles = true;
  }

  if (key === "d" || key === "D") {
    if (particles.length > 1) {
      particles.pop();
    }
  }
}

function keyReleased() {
  if (key === "a" || key === "A") {
    addparticles = false;
  }
}

function add_dark_star() {
  stars.push(new star(mouseX, mouseY));
}
