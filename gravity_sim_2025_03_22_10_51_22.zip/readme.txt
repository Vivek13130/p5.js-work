 making gravity simulator :

step 1 -- make two classes one of particle and one of star ,and they can be added using
 mouse clicks :

step 2 -- now if a dark star is present , it should exert some force
on every particle , based on distance
and the forces on the particles should make it move accordingly

step 3 -- now forces are added

step 5 -- make the stars attract to stars 

---------------------------------------------------------------
pending : 

make the stars position to appear next to screen , they should not go out of the window

step 4 -- adding trails - that change according to velocity 
we can also add a color changing feature on particles making them change there color on increasing speed 



step 6 -- merging star and exploding them on a certain mass 
here also add color to show how much it is near to explode 

step 7 -- star animation -- blinking and getting little bit transparent from inside on getting bigger 

step 8 -- drag star using mouse 

step 9 -- A - add particle( at mouse position ) , D - delete particle randomly , click - add star 

step 10 -- some stats on the screen : 
fps
total kinetic energy 
average speed of particles 
total mass of stars 
total mass of particles 
 
 total particles 
 total stars 
time elapsed on the simulation 


step 11 -- adjustable features ( user can control ) 
-- trail length 
-- max speed of particles 
-- trail on off 
-- starting particle count 
-- initial velocity range 
-- pause / continue / reset
-- 



extra --
i am thinking to lay off some cookies to give me info about site , like how many time people used the simulation for etc etc 
