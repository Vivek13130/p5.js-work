let x1,y1, x2,y2, x3,y3, x4,y4;
let xoff = 0;
let yoff = 0;
let stroke_color = "rgb(255,0,211)";

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(0);
}

function draw() {
    
  x1 = noise(xoff + 5) * width;
  x2 = noise(xoff + 100) * width;
  x3 = noise(xoff + 15) * width;
  x4 = noise(xoff + 200) * width;
  
  y1 = noise(yoff + 10) * height;
  y2 = noise(yoff + 200) * height;
  y3 = noise(yoff + 300) * height;
  y4 = noise(yoff + 20) * height;
  
  xoff += 0.01;
  yoff += 0.01;
  
  noFill();
  strokeWeight(0.1);
  
  stroke(stroke_color)
  
  bezier(x1,y1,  x2,y2,  x3,y3,  x4,y4);
  
  
  
  // print(frameRate);
}

