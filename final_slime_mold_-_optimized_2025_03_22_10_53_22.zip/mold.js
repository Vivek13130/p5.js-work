
class mold{
  
  constructor(){
    this.x = random(canvas_width);
    this.y = random(canvas_height);
    this.r = radius;
    
    this.heading = random(360);
    
    // for converting polar into cartesian system
    this.vx = cos(this.heading);
    this.vy = sin(this.heading);
    
    this.lsensorpos = createVector(0,0);
    this.rsensorpos = createVector(0,0);
    this.fsensorpos = createVector(0,0);
    
    this.sensorangle = sensing_angle;
    this.sensordist = sensing_distance;
    
    this.rotangle = rotate_angle;
    
    let r = random(0,255);
    let g = random(0,255);
    let b = random(0,255);
    
    this.colors = color(r,g,b);
  }
  
  update(){
    // making the mold move : 
    this.vx = cos(this.heading);
    this.vy = sin(this.heading);
    
    this.x = (this.x + this.vx + canvas_width) % canvas_width;
    this.y = (this.y + this.vy + canvas_height) % canvas_height;
    
    
    this.sensor_pos(this.lsensorpos, this.heading - this.sensorangle);
    this.sensor_pos(this.rsensorpos, this.heading + this.sensorangle);
    this.sensor_pos(this.fsensorpos, 0);
    
    
    
    let index , l , r , f; 
    // index is the index of pixel on screen that we want 
    // l r f will store the value of color on that pixel 
    
    index = 4 * ( d * floor(this.rsensorpos.y)) * (d * canvas_width) + 4 * ( d * floor(this.rsensorpos.x));
    r = pixels[index];
    
    index = 4 * ( d * floor(this.lsensorpos.y)) * (d * canvas_width) + 4 * ( d * floor(this.lsensorpos.x));
    l = pixels[index];
    
    index = 4 * ( d * floor(this.fsensorpos.y)) * (d * canvas_width) + 4 * ( d * floor(this.fsensorpos.x));
    f = pixels[index];
    

    
    
    if ( f < l && f < r){
      if(random(1) > 0.5){
        this.heading += this.rotangle;
      }
      else{
        this.heading -= this.rotangle;
      }
    }
    else if( l > r ){
      this.heading -= this.rotangle;
    }
    else if(r > l ){
      this.heading += this.rotangle;
    }
  }
  
  display(){
    
    fill(this.colors)
    noStroke();
    ellipse(this.x, this.y , this.r*2, this.r*2);
  }
  
  sensor_pos(sensor , heading){
    sensor.x = (this.x + this.sensordist * cos(heading) + canvas_width) % canvas_width;
    sensor.y = (this.y + this.sensordist * sin(heading) + canvas_height) % canvas_height;
  }
  
}