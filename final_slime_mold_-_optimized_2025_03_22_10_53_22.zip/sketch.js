// adjust here : 
// code is optimized to support up to 7000 molds
// at a good frame rate 

let num = 2000;


let randomvalues = false; 
// you can set it true to get random results every time 
// if set to true , the bottom values won't matter

let sensing_angle = 30;
let sensing_distance = 30;
let rotate_angle = 30;


let radius = 0.5;
let canvas_width ;
let canvas_height ;



// best combinations : 
// 500,45,45,30



let molds = [];
let d 

function setup() {
  canvas_width = 600;
  canvas_height = 600;
  createCanvas(canvas_width, canvas_height);
  
  if(randomvalues){
    sensing_angle = random(20,90);
    sensing_distance = random(10,60);
    rotate_angle = random(20,60);
  }
  
  
  d =  pixelDensity(); 
  
  angleMode(DEGREES);
  
  for(let i = 0; i<num ; i++){
    molds.push(new mold());
  }
}

function draw() {
  background(10,4);
  loadPixels();
  
  for(let i = 0 ; i<num; i++){
    molds[i].update();
    molds[i].display();
  }
  

  
}