let xoff = 100;
let yoff = 100;

let xdiff , ydiff;

let xprev;
let yprev;

function setup() {
  createCanvas(windowWidth, windowHeight);
  // x = width/2;
  // y = width/2;
  background(0);
  
  xprev = width/2;
  yprev = height/2;
}

function draw() {
  let perlinx = noise(xoff);
  let perliny = noise(yoff);
  
  let x = map(perlinx, 0, 1, 0, width);
  let y = map(perliny, 0, 1, 0, height);
  
  fill(255);
  stroke(255);
  
  line(xprev,yprev, x,y);
  
  
  xprev = x;
  yprev = y;
  
  xdiff = random(0.005, 0.01);
  ydiff = random(0.001, 0.02);
  
  // xdiff = 0.01;
  // ydiff = 0.013;
  
  xoff += xdiff;
  yoff += ydiff;
}