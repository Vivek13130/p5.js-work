let rows = 40;
let cols = 40;

let l,b;

function setup() {
  createCanvas(windowWidth, windowHeight);
  l = windowWidth/cols;
  b = windowHeight/rows;
}

function draw() {
  
  background(0);
  
  for(let i = 0 ; i< rows; i++){
    
    // now in a row : 
    
    for(let j = 0; j<cols; j++){
      
      stroke(255,255,255);
      fill(140);
      
      // noFill();
      // noStroke();
      
      let posx = i*l;
      let posy = j*b;
      let distance = dist(mouseX, mouseY, posx, posy)
      
      if( distance < 200){
        let l1 = map(distance , 0 , 200 , 0.01 , 1) * l;
        let b1 = map(distance , 0 , 200 , 0.01 , 1) * b;
        rect(i * l , j * b , l1, b1);
      }
      else{
        rect(i * l , j * b , l, b);
      }
      
    }
    
  }
  
  
}