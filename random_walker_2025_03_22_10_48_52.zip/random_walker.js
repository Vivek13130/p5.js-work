class walker{
  // position of the object 
  
  constructor(){
    this.x = width/2;
    this.y = height/2;
    
    this.dx = 0 ;
    this.dy = 0;
    this.r = random(0,256);
    this.g  = random(0,256);
    this.b = random(0,256);
    this.move_limit = random(-10,10);
  } 
  
  direction_change(){
    this.dx =  random(- this.move_limit, this.move_limit)
    this.dy =  random(- this.move_limit, this.move_limit)
  }
    
  display(){
    strokeWeight(2);
    stroke(this.r, this.g, this.b );
    
    
    line(this.x , this.y , this.x + this.dx , this.y + this.dy);
    this.x += this.dx;
    this.y += this.dy;
    
  }
  
}