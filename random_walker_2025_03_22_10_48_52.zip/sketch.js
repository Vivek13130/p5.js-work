
let w1;
let objects = 20;
let arr = [];

function setup() {
  createCanvas(400,400);
  w1 = new walker();
  background(220);
  
  for(let i = 0; i<objects; i++){
    let obj = new walker();
    arr.push(obj);
  }
  
}

function draw() {
  // w1.direction_change();
  // w1.display();
  
  for(let i = 0 ; i<arr.length; i++){
    arr[i].direction_change();
    arr[i].display();
  }
}