let sensing_dist = 30; // the distance upto which rectangles react.
let size = 30 ; // size of square ;
let rotation_speed = 6; // the speed of rotation of rectangles .
let offset = 10; // this will define the size between rectangles 
let disappear_speed = 3; // the speed with which s



let cols  ; 
let rows  ; 
// for making the screen as grid ;


let blocks = []; // an array for storing all objects ( block objects );


function setup() {
  createCanvas(windowWidth*0.9, windowHeight*0.9);
  
  rectMode(CENTER); // now the rectangle will be placed by center , not the top left corner 
  angleMode(DEGREES); // to specify that all angles are in degrees, not radian
  
  
  // now first we need to make multiple block objects and store the objects in the array 
  // we are initializing cols and rows here , because height and width are available only after canvas is created .
  
  rows = width/size;
  cols = height/size;
  
  noFill();
  strokeWeight(1);
  strokeJoin(1);
  
  for(let i = 0 ; i<rows ; i++){
    
    blocks[i] = []; // here we declared the ith element in array as another array , now this array can be used as 2d array ( to sum up );
    
    for(let j=0; j < cols ; j++){
      
      blocks[i][j] = new Block(i*size + size/2 , j*size + size/2);
      // now the rectangle is made with coordinates of top left corner 
    }
  }
  
}

function draw() {
  background(0);
  
  for(let i = 0 ; i<rows ; i++){
    for(let j=0; j < cols ; j++){
      blocks[i][j].move();
      blocks[i][j].display();
    }
  }
  
}